import static org.junit.Assert.assertEquals;

/*
 * Testklasse für die Klasse Videospiel
 * 
 * @author Ihor, Oweiss
 */
public class VideospielTest
{
    private Videospiel _videospielTest;
    private String _kommentar;
    private String _titel;
    private String _konsole;
    private String _bezeichnung;

    public VideospielTest()
    {
        _kommentar = "Abenteuerspiel";
        _titel = "Skyrim";
        _konsole = "PC";
        _bezeichnung = "Spiel";

        _videospielTest = new Videospiel(_kommentar, _titel, _konsole);
    }

    public void getKommentarTest()
    {
        assertEquals(_kommentar, _videospielTest.getKommentar());
    }

    public void getMedienBezeichnungTest()
    {
        assertEquals(_bezeichnung, _videospielTest.getMedienBezeichnung());
    }

    public void getTitelTest()
    {
        assertEquals(_titel, _videospielTest.getKommentar());

    }

    public void getKonsoleTest()
    {
        assertEquals(_konsole, _videospielTest.getKommentar());

    }

    public void getFormatiertenSring()
    {
        assertEquals(_konsole, _videospielTest.getKommentar());
    }

}
