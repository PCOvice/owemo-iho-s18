import java.util.List;

import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 * Ein MedienDetailAnzeigerWerkzeug ist ein Werkzeug um die Details von Medien
 * anzuzeigen.
 * 
 * @author SE2-Team
 * @version SoSe 2017
 */
class MedienDetailAnzeigerWerkzeug
{
    private MedienDetailAnzeigerUI _ui;
    String _textUI; //für die Ausgabe im UI NEU!!!

    /**
     * Initialisiert ein neues MedienDetailAnzeigerWerkzeug.
     */
    public MedienDetailAnzeigerWerkzeug()
    {
        _ui = new MedienDetailAnzeigerUI();
    }

    private void medienTypzusicherung(List<Medium> medien) //für aufgabe 3.2.1
    {
        for (Medium k : medien)
        {
            String textUIPart = k.getMedienBezeichnung() + k.getTitel()
                    + k.getKommentar(); //ich weiß alle werden diese Eigenschaft teilen.

            if (k.getMedienBezeichnung()//VIDEOSPIEL!!!
                .equals("Videospiel"))
            {
                if (k instanceof Videospiel) //Typtest
                {
                    Videospiel a = (Videospiel) k;//Typzusicherung
                    _textUI = textUIPart + a.getKonsole();
                }
            }

            if (k.getMedienBezeichnung()
                .equals("DVD")) //DVD!!!!
            {
                if (k instanceof DVD)
                {
                    DVD b = (DVD) k;
                    _textUI = textUIPart + b.getLaufzeit() + b.getRegisseur();
                }
            }

            if (k.getMedienBezeichnung()
                .equals("CD")) //CD!!!
            {
                if (k instanceof CD)
                {
                    CD c = (CD) k;
                    _textUI = textUIPart + c.getSpiellaenge()
                            + c.getInterpret();
                }
            }
        }
    }

    /**
     * Setzt die Liste der Medien deren Details angezeigt werden sollen.
     * 
     * @param medien Eine Liste von Medien.
     * 
     * @require (medien != null)
     */
    public void setMedien(List<Medium> medien)
    {
        //medienTypzusicherung(medien); //das komplette auskommentieren der Hilfsmethode ist somit nicht nötig. 

        assert medien != null : "Vorbedingung verletzt: (medien != null)";
        JTextArea selectedMedienTextArea = _ui.getMedienAnzeigerTextArea();

        for (Medium k : medien) //Aufgabe 3.2.2
        {
            _textUI = k.getFormatiertenString();
        }

        selectedMedienTextArea.setText(_textUI);
    }

    /**
     * Gibt das Panel dieses Subwerkzeugs zurück.
     * 
     * @ensure result != null
     */
    public JPanel getUIPanel()
    {
        return _ui.getUIPanel();
    }
}
mme