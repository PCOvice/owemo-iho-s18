
/*
 * Videospiel als Medium
 * @author Oweiss, Ihor
 * 
 */
public class Videospiel implements Medium
{

    private String _titel;
    private String _konsole;
    private String _kommentar;

    /**
     * Im Konstruktor werden die neuen Videospiele mit Titel, Konsole
     * und Kommentar initialisiert.
     * 
     * @param kommentar kommentar des Spiels
     * @param titel Titel des Spiels
     * @param konsole Das System auf die das Spiel gespielt werden kann. 
     * 
     */
    public Videospiel(String kommentar, String titel, String konsole)
    {
        _titel = titel;
        _kommentar = kommentar;
        _konsole = konsole;
    }

    @Override
    public String getKommentar()
    {
        return _kommentar;
    }

    @Override
    public String getMedienBezeichnung()
    {
        return "Spiel";
    }

    @Override
    public String getTitel()
    {
        return _titel;
    }

    public String getKonsole()
    {
        return _konsole;
    }

    public String getFormatiertenString()
    {
        return getTitel() + "\n" + getKonsole() + "\n" + getKommentar() + "\n"
                + getMedienBezeichnung();
    }
}
